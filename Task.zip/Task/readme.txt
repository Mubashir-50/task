username: admin
password: admin



superuser:admin
password:admin


while registering password must be alphanumeric