from django.contrib.auth import authenticate,login,logout
from django.shortcuts import render,HttpResponse,redirect,get_object_or_404, HttpResponseRedirect,reverse
from .forms import blogform
from .models import blog,Author
from .forms import CreateUserForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


# Create your views here

def registerpage(request):
    if request.user.is_authenticated:
        return redirect(home)
    else:
        form=CreateUserForm()
        if request.method == 'POST':
            form= CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user=form.cleaned_data.get('Username')
                messages.success(request,"Account was created ")
                return redirect('login')
        context={'form':form}
        return render(request,'register.html',context)
        
def loginpage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method=='POST':
            username=request.POST.get('username')
            password=request.POST.get('password')
            
            user=authenticate(request,username=username,password=password)
            if user is not None:
                login(request,user)
                return redirect('home')
            else:
                messages.info(request,'Username or Password incorrect')
        context={}
        return render(request,'login.html',context)
    
def logoutuser(request):
    logout(request)
    return redirect('login')
        
def add (request):
    if request.method=='POST':
        form = blogform(request.POST)
        if form.is_valid:
            form.save()
    return redirect('/')
def listview(request):
    context=blog.objects.all()
    return render(request,'add.html',{'blogs':context})
def home1(request):
    blogs=blog.objects.all()
    titles = blog.objects.values('id', 'title')
    context={'blogs':blogs,'titles':titles}
    return render(request,'home1.html',context)
@login_required(login_url='login')
def home(request):
    form=blogform
    blogs=blog.objects.all()
    titles = blog.objects.values('id', 'title')
    context={'form':form , 'blogs':blogs,'titles':titles}
    return render(request,'home.html',context)
def blog_detail(request, id):
    post = get_object_or_404(blog, id=id)
    return render(request, 'detail.html', {'post': post})
@login_required(login_url='login')
def update(request,id):
    updated=blog.objects.get(id=id)
    form=blogform(request.POST,instance=updated)
    if form.is_valid():
        form.save()
        return redirect('/')
    else:
        form = blogform(instance=updated)
    return render(request, 'edit.html', {'form': form})
@login_required(login_url='login')
def edit(request,id):
    getblog=blog.objects.get(id=id)
    return render(request, 'edit.html',{'blog':getblog})
@login_required(login_url='login')
def delete(request,id):
    getblog=blog.objects.get(id=id)
    getblog.delete()
    return redirect('/')

@login_required(login_url='login')
def change(request, id):
    original_blog = get_object_or_404(blog, id=id)
    if request.method == 'POST':
        form = blogform(request.POST, request.FILES, instance=original_blog)
        if form.is_valid():
            original_blog.delete()
            updated_blog = form.save()
            return HttpResponseRedirect(reverse('listview'))
    else:
        form = blogform(instance=original_blog)
    return render(request, 'edit.html', {'form': form})
