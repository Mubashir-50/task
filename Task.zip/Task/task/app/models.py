'''Models
   - Create two models: `Author` and `BlogPost`.
   - The `Author` model should have fields for the user's username, email, and password (feel free to add more fields of your choice)
   - The `BlogPost` model should have fields for the title, content, publication date, and an image (cover image) associated with each blog post. Use a foreign key to associate each blog post with an author.
'''

from django.db import models
from django.contrib.auth.models import *
# Create your models here.

class Author(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name=models.CharField( max_length=50 , null = True , blank = True)
    email=models.CharField(max_length=100, null = True , blank = True)
   
   
    def __str__(self):
           return self.name
   
class blog(models.Model):
    # author = models.ForeignKey(Author, on_delete=models.CASCADE)
    title = models.CharField(max_length=200, null = True , blank = True)
    text = models.TextField()
    image = models.ImageField(upload_to='images/', blank=True, null=True)

    def __str__(self):
        return self.title